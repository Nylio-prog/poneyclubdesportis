(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_22081b27._.js",
  "static/chunks/node_modules_framer-motion_dist_es_011a2bde._.js",
  "static/chunks/node_modules_531278bb._.js",
  "static/chunks/_5145930c._.js"
],
    source: "dynamic"
});
