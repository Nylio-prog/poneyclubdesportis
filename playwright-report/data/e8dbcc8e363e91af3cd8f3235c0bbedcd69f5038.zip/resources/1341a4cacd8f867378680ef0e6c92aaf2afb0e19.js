(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_a1d49073._.js",
  "static/chunks/node_modules_@popperjs_core_lib_edc15795._.js",
  "static/chunks/node_modules_react-big-calendar_dist_react-big-calendar_esm_f64ee0b7.js",
  "static/chunks/node_modules_moment_87c24e78._.js",
  "static/chunks/node_modules_2c1bae13._.js",
  "static/chunks/_dd31b143._.js",
  "static/chunks/node_modules_react-big-calendar_lib_css_react-big-calendar_3590fab3.css"
],
    source: "dynamic"
});
